//completed---fully same
package com.stackroute.myfavouriteservice.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class User {
	
	@Id
	private String username;
	
	
	private List<Walmart> NameList;


	public String getUsername() {
		return username;
	}


	public void setUsername(String username) {
		this.username = username;
	}


	


	public List<Walmart> getNameList() {
		return NameList;
	}


	public void setNameList(List<Walmart> nameList) {
		NameList = nameList;
	}


	@Override
	public String toString() {
		return "User [username=" + username + ", walmartList=" + NameList + "]";
	}


	public User(String username, List<Walmart> NameList) {
		super();
		this.username = username;
		this.NameList = NameList;
	}


	public User() {
		super();
		//TODO Auto-generated constructor stub
	}

	
}
