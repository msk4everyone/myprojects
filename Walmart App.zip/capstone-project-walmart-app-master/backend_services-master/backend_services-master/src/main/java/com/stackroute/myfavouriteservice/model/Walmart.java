//completed---fully same
package com.stackroute.myfavouriteservice.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import org.springframework.data.annotation.Id;

public class Walmart {
	
//	  pid: string;
//	  fullName: String;
//	  name: String;
//	  country:String;
	
	@Id
    private String name;
  


    @JsonProperty("price")
    private String price;
    
    @JsonProperty("stock")
    private String stock;

    @JsonProperty("rating")
    private String rating;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getStock() {
		return stock;
	}

	public void setStock(String stock) {
		this.stock = stock;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public Walmart(String name, String price, String stock, String rating) {
		super();
		this.name = name;
		this.price = price;
		this.stock = stock;
		this.rating = rating;
	}

	public Walmart() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Walmart [name=" + name + ", price=" + price + ", stock=" + stock + ", rating=" + rating + "]";
	}

}