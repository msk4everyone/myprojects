package com.stackroute.myfavouriteservice.service;

import java.util.List;

import com.stackroute.myfavouriteservice.exception.NameAlreadyExistsException;
import com.stackroute.myfavouriteservice.exception.NameNotFoundException;
import com.stackroute.myfavouriteservice.model.Walmart;
import com.stackroute.myfavouriteservice.model.User;

import org.springframework.stereotype.Service;


public interface FavouriteService {
	
	public User saveNameToFavorite(Walmart Walmart, String username) throws NameAlreadyExistsException;
	public User deleteNameFromFavorite(String trackId , String username ) throws NameNotFoundException;
	public List<Walmart> getNameList(String username ) throws Exception;

}
