package com.stackroute.myfavouriteservice.service;

import java.util.ArrayList;
import java.util.List;

import com.stackroute.myfavouriteservice.exception.NameAlreadyExistsException;
import com.stackroute.myfavouriteservice.exception.NameNotFoundException;
import com.stackroute.myfavouriteservice.model.Walmart;
import com.stackroute.myfavouriteservice.model.User;
import com.stackroute.myfavouriteservice.repository.FavouriteRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class FavouriteServiceImpl implements FavouriteService{
	
//	@Autowired
	private FavouriteRepository favRepository;
	
	@Autowired
	public FavouriteServiceImpl(FavouriteRepository favRepository) {
		super();
		this.favRepository = favRepository;
	}

	@Override
	public User saveNameToFavorite(Walmart walmart, String username) throws NameAlreadyExistsException {
		// TODO Auto-generated method stub
		User user1 = favRepository.findByUsername(username);
		
		if (user1 == null) {
			user1 = new User(username, new ArrayList<Walmart>());
		}
		
		List<Walmart> walmartList = user1.getNameList();

		if (walmartList != null) {
			for (Walmart p : walmartList) {

				if (p.getName().equals(walmart.getName())) {
					throw new NameAlreadyExistsException();
				}
			}

			walmartList.add(walmart);
			
			System.out.println("Saving Data if block");
			user1.setNameList(walmartList);
			favRepository.save(user1);
		}

		else {
			walmartList = new ArrayList();
			walmartList.add(walmart);

			user1.setNameList(walmartList);
			favRepository.save(user1);
		}
		return user1;

	}
	
	

	@Override
	public User deleteNameFromFavorite(String name, String username) throws NameNotFoundException {
		User user1 = favRepository.findByUsername(username);
		boolean trackFound = false;
		int indexnum = 0;
		List<Walmart> walmartList = user1.getNameList();

		if (walmartList != null && walmartList.size() > 0) {
			for (Walmart t : walmartList) {
				indexnum++;
				if (t.getName().equals(name)) {
					walmartList.remove(indexnum - 1);
					user1.setNameList(walmartList);
					favRepository.save(user1);
					break;
				}
			}

		}

		else {
			throw new NameNotFoundException();
		}
		return user1;
	}

	@Override
	public List<Walmart> getNameList(String username) throws Exception {
		User user1 = favRepository.findByUsername(username);
		return user1.getNameList();
	}


}
