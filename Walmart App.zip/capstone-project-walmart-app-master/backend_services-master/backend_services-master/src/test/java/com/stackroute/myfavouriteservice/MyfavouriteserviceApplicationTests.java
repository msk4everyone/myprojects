package com.stackroute.myfavouriteservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyfavouriteserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
