package com.stackroute.myfavouriteservice.service;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.List;

import com.stackroute.myfavouriteservice.exception.NameAlreadyExistsException;
import com.stackroute.myfavouriteservice.exception.NameNotFoundException;
import com.stackroute.myfavouriteservice.model.Walmart;
import com.stackroute.myfavouriteservice.model.User;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;


class FavouriteServiceImplTest {

	 private User user;
	    private Walmart walmart, walmart1;
	    List<Walmart> list;

	    @BeforeEach
	    public void setUp() {
	        user = new User();
	        walmart = new Walmart();
	        walmart.setName("india");
	        walmart.setPrice("172817281");
	        walmart.setStock("6677777");
	        walmart.setRating("88999");
	        user.setUsername("pallavi");
	        list = new ArrayList<>();
	        list.add(walmart);
	        user.setNameList(list);
	    }

	    @AfterEach
	    public void tearDown() {
	        walmart = null;
	        user = null;
	    }

	    @Test
	    public void testSaveWatchListForUser() throws NameAlreadyExistsException {
	    	FavouriteServiceImpl service = mock(FavouriteServiceImpl.class);
	        when(service.saveNameToFavorite(walmart, "pallavi")).thenReturn(user);
	        User dummy = service.saveNameToFavorite(walmart, "pallavi");
	        assertNotNull(dummy);
	    }

	    @Test
	    public void testViewWatchListForUser() throws Exception {
	    	FavouriteServiceImpl service = mock(FavouriteServiceImpl.class);
	    	walmart1 = new Walmart();
	    	walmart1.setName("USA");
	        walmart1.setPrice("172817281");
	        walmart1.setStock("6677777");
	        walmart1.setRating("88999");
	        list.add(walmart);
	        user.setNameList(list);
	        when(service.getNameList("pallavi")).thenReturn(list);
	        List<Walmart> list1 = service.getNameList("pallavi");
	        assertNotNull(list1);
	        assertEquals(list1.size(), list.size());

	    }

	    @Test
	    public void testDeleteWatchListForUser() throws NameNotFoundException {
	    	FavouriteServiceImpl service = mock(FavouriteServiceImpl.class);
	        when(service.deleteNameFromFavorite("india", "pallavi")).thenReturn(null);
	        User dummy = service.deleteNameFromFavorite("india", "pallavi");
	        assertNull(dummy);

	    }

}
